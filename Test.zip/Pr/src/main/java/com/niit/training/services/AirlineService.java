package com.niit.training.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.niit.training.model.Airlines;
@Service
public interface AirlineService {

	void addAirline(String airlineCode, String airlineName);
	void deleteAirline(String airlineCode);
	List<Airlines> listAllAirline();
	void updateAirline(String airlineCode, String airlineName);
	Airlines getAirline(String airlineCode);
	
}
