package com.niit.training.services;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niit.training.model.Airlines;
import com.niit.training.dao.AirlinesDao;

@Service
@Transactional
public class AirlineServiceImpl implements AirlineService {

	List<Airlines> airlines = new ArrayList<Airlines>();
	
	@Autowired
	AirlinesDao airlineDao;
	
	public AirlineServiceImpl() {
		super();
	}
	
	@Transactional
	@Override
	public void addAirline(String airlineCode, String airlineName) {
		// TODO Auto-generated method stub

		Airlines airline = new Airlines(airlineCode, airlineName);
		airlineDao.add(airline);
	}

	

	@Override
	public void deleteAirline(String airlineCode) {
		
		airlineDao.delete(airlineCode); 

	}

	@Override
	public List<Airlines> listAllAirline() {
		// TODO Auto-generated method stub
		return airlineDao.listAll();
	}

	@Override
	public void updateAirline(String airlineCode, String airlineName) {
		// TODO Auto-generated method stub
		Airlines airline = getAirline(airlineCode);
		airline.setAirlineName(airlineName);
	  	airlineDao.update(airline); 

	}

	@Override
	public Airlines getAirline(String airlineCode) {
		// TODO Auto-generated method stub
		return  airlineDao.getAirlineByCode(airlineCode);
	}

}
