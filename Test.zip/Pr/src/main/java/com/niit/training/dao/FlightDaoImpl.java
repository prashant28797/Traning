package com.niit.training.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import org.hibernate.Session;


import com.niit.training.model.Flight;
@Repository
public class FlightDaoImpl implements FlightDao{

	@Autowired
	SessionFactory sessionFactory;
	
	@Override
	public void addflight(Flight flight) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		session.save(flight);
	}

	@Override
	public void delete(String flightCode) {
		// TODO Auto-generated method stub
		
		Flight flights=getFlightByCode(flightCode);
		this.sessionFactory.getCurrentSession().delete(flights);
	}

	@Override
	public List<Flight> listAll() {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		//Airline is entity class mapped to airline table
		return session.createQuery("from Flight").list(); 
	
	}

	
	public void update(Flight flight) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Flight getFlightByCode(String flightcode) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		return (Flight) session.get(Flight.class, flightcode);
	
	}

}
