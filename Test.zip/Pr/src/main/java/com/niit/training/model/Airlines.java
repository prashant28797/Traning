package com.niit.training.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="airline")
public class Airlines {

	@Id
	private String airlineCode;
	
	private String airlineName;
	
	
	public Airlines() {
		super();
	}
	public Airlines(String code2, String name2) {
		// TODO Auto-generated constructor stub
		airlineCode=code2;
		airlineName=name2;
	}
	public String getAirlineCode() {
		return airlineCode;
	}
	public void setAirlineCode(String code) {
		this.airlineCode = code;
	}
	public String getAirlineName() {
		return airlineName;
	}
	public void setAirlineName(String name) {
		this.airlineName = name;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((airlineCode == null) ? 0 : airlineCode.hashCode());
		result = prime * result + ((airlineName == null) ? 0 : airlineName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Airlines other = (Airlines) obj;
		if (airlineCode == null) {
			if (other.airlineCode != null)
				return false;
		} else if (!airlineCode.equals(other.airlineCode))
			return false;
		if (airlineName == null) {
			if (other.airlineName != null)
				return false;
		} else if (!airlineName.equals(other.airlineName))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "code=" + airlineCode + ", name=" + airlineName ;
	}
	
	
}
