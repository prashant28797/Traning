package com.niit.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.training.model.Flight;
import com.niit.training.services.SearchFlightService;
@Controller
public class SearchFlightController {

	@Autowired
	SearchFlightService service;

	/*@RequestMapping(value = "/searchFlight", method = RequestMethod.GET)
	public ModelAndView searchFlight() {

		return new ModelAndView("searchflight");
	}*/

	@RequestMapping(value = "/searchFlight", method = RequestMethod.POST)
	public ModelAndView searchFlight(@RequestParam String sourceAirport, @RequestParam String destinationAirport,
			@RequestParam String date, @RequestParam int seats) {

		List<Flight> flights = service.selectAllFlights(sourceAirport, destinationAirport, date, seats);
		if (flights != null && flights.size() > 0) {
			ModelAndView view = new ModelAndView("flights");

			return view;
		}
		return null;
	}
}