package com.niit.training.dao;

import java.util.List;

import com.niit.training.model.Flight;

public interface SearchFlightDao {

	public List<Flight> selectAllFlights(final String sourceAirport, final String destinationAirport, final String date,final int seats);
	public int getAvailableSeats(final String flightCode, int seats);
	public void updateSeats(final String flightCode, final int newSeats);
}