package com.niit.training.model;

public class SearchFlight {
   private String flightcode;
   private String departure_time;
   private String arrival_time;
   private String duration;
  // private String price;
   
   public SearchFlight(){
	   
   }

public String getFlightcode() {
	return flightcode;
}
public void setFlightcode(String flightcode) {
	this.flightcode = flightcode;
}
public String getDeparture_time() {
	return departure_time;
}
public void setDeparture_time(String departure_time) {
	this.departure_time = departure_time;
}
public String getArrival_time() {
	return arrival_time;
}
public void setArrival_time(String arrival_time) {
	this.arrival_time = arrival_time;
}
public String getDuration() {
	return duration;
}
public void setDuration(String duration) {
	this.duration = duration;
}
/*public String getPrice() {
	return price;
}
public void setPrice(String price) {
	this.price = price;
}*/

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	SearchFlight other = (SearchFlight) obj;
	
	if (arrival_time == null) {
		if (other.arrival_time != null)
			return false;
	} else if (!arrival_time.equals(other.arrival_time))
		return false;
	if (departure_time == null) {
		if (other.departure_time != null)
			return false;
	} else if (!departure_time.equals(other.departure_time))
		return false;
	if (duration == null) {
		if (other.duration != null)
			return false;
	} else if (!duration.equals(other.duration))
		return false;
	if (flightcode == null) {
		if (other.flightcode != null)
			return false;
	} else if (!flightcode.equals(other.flightcode))
		return false;
	/*if (price == null) {
		if (other.price != null)
			return false;
	} else if (!price.equals(other.price))
		return false;*/
	return true;
}
   
   
}
