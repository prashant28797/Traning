package com.niit.training.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.training.model.Airlines;
import com.niit.training.dao.AirlinesDao;
@Repository
public class AirlinesDaoImpl implements AirlinesDao {

	@Autowired
	SessionFactory sessionFactory;
	@Override
	public void add(Airlines airline) {
		// TODO Auto-generated method stub

		Session session = sessionFactory.getCurrentSession();
		session.save(airline);
	}

	@Override
	public void delete(String airlineCode) {
		// TODO Auto-generated method stub
		//Session session = sessionFactory.getCurrentSession();
		// session.createQuery("delete from Airlines where airlineCode = :airlineCode").executeUpdate();

		 Airlines airline = getAirlineByCode(airlineCode);
		 this.sessionFactory.getCurrentSession().delete(airline);
	} 

	@Override
	public List<Airlines> listAll() {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		return session.createQuery("from Airlines").list(); 
	}

	@Override
	public void update(Airlines airline) {
		// TODO Auto-generated method stub
		//Airlines airlines = getAirlineByCode(airlineCode);
		this.sessionFactory.getCurrentSession().update(airline);

	}

	@Override
	public Airlines getAirlineByCode(String airlineCode) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		return (Airlines) session.get(Airlines.class, airlineCode);
	}

}
