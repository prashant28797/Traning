package com.niit.training.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;


@Controller
public class WelcomeController {

	

	@RequestMapping(value = "/hello1", method = RequestMethod.GET)
	public String sayHello1() {
		return "Admin";
	}
	
	@RequestMapping(value = "/hello", method = RequestMethod.GET)
	public String sayHello() {
		return "login";
	}

}
