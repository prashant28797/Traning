package com.niit.training.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.niit.training.model.FlightSchedule;

@Repository
public class FlightScheduleImpl implements FlightScheduleDao {

	@Autowired
	SessionFactory sessionFactory;
	
	public FlightScheduleImpl() {
		
	}

	@Override
	public void add(FlightSchedule schedule) {
		Session session = sessionFactory.getCurrentSession();
		session.save(schedule);
	}

	@Override
	public void deleteFlightSchedule(String scheduleid) {
		// TODO Auto-generated method stub
		   FlightSchedule flight=getFlightScheduleByCode(scheduleid);
		   this.sessionFactory.getCurrentSession().delete(flight);
	}

	@Override
	public List<FlightSchedule> listAll() {
		Session session = sessionFactory.getCurrentSession();
		//Airline is entity class mapped to airline table
		return session.createQuery("from FlightSchedule").list(); 
	}

	//@Override
	/*public void update(FlightSchedule airline) {
		// TODO Auto-generated method stub

	}*/

	@Override
	public FlightSchedule getFlightScheduleByCode(String scheduleid) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		return (FlightSchedule) session.get(FlightSchedule.class, scheduleid);
	}

}