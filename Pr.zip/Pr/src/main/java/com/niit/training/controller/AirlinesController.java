package com.niit.training.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.training.model.Airlines;
import com.niit.training.services.AirlineService;

@Controller
public class AirlinesController {

	@Autowired
	AirlineService service;
	
	@RequestMapping(value = "/Add", method = RequestMethod.GET)
	public String addAirlines() {
		return "addairlines";
	}
	
	
	@RequestMapping(value = "/addAir", method = RequestMethod.POST)
	public ModelAndView addAirlines(@RequestParam String airlineCode, @RequestParam String airlineName,@RequestParam String cost)
	{
		if(service.getAirline(airlineCode)!=null)
		{
			String msgValue = "Airlines "+airlineName+" already present.";
			return new ModelAndView("addairlines", "errorMessage", msgValue);
		}
		else {
			service.addAirline(airlineCode, airlineName,cost);
			String msgValue = "Airlines with "+airlineName+" added.";
			return new ModelAndView("addairlines", "welcomeMessage", msgValue);
		}
	}
	
	@RequestMapping(value="/displayAirlines", method=RequestMethod.GET)
	public ModelAndView display()
	{
		return new ModelAndView("displayairlines","airlines",service.listAllAirline());
	}
	
	@RequestMapping(value="/deleteAirlines", method=RequestMethod.GET)
	public ModelAndView delete(@RequestParam String airlineCode)
	{
	     service.deleteAirline(airlineCode);
	     ModelAndView view = new ModelAndView("displayairlines");
	     view.addObject("airlines", service.listAllAirline());
	     view.addObject("message", "Deleted Successfully");
	     return view;
	}
	
	@RequestMapping(value="/editAirlines" , method=RequestMethod.GET)
	public ModelAndView edit(@RequestParam String airlineCode)
	{
		Airlines airlines= service.getAirline(airlineCode);
		ModelAndView view = new ModelAndView("editairlines");
		view.addObject("airlines",airlines);
		return view;
		
	}
	
	@RequestMapping(value="/editAirlines", method= RequestMethod.POST)
	public ModelAndView editSubmit(@RequestParam String airlineCode, @RequestParam String airlineName,
			@RequestParam String newName)
	{
		Airlines airlines = service.getAirline(airlineCode);
		
		if(airlines==null)
		{
			ModelAndView view = new ModelAndView("displayairlines");
			view.addObject("airlines", service.listAllAirline());
			view.addObject("errorMessage","Not Found");
			return view;
		}
		
		service.updateAirline(airlineCode, newName); 
		ModelAndView view = new ModelAndView("displayairlines");
		view.addObject("airlines", service.listAllAirline());
		view.addObject("message", "Successfully Updated");
		return view;
	 	
	}
}
