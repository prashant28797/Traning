package com.niit.training.services;

import java.util.List;

import javax.ejb.TransactionAttribute;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.niit.training.dao.FlightScheduleDao;
//import com.niit.training.dao.FlightScheduleDaoImpl;
import com.niit.training.model.FlightSchedule;

@Service
@Transactional
class FlightScheduleServiceImpl implements FlightScheduleService {

	@Autowired
	FlightScheduleDao  flight;
	
	public FlightScheduleServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	@Transactional
	public void addFlightSchedule(String scheduleid, String source_airport, 
			 String destination_airport,
		 String departure_time,	 String arrival_time,
			 String duration,
			 String distance,String date,String flightCode) {
		FlightSchedule  schedule = new FlightSchedule(scheduleid,source_airport,destination_airport,departure_time,arrival_time,duration,distance,date,flightCode);
		flight.add(schedule);
	}

	@Override
	public void deleteFlightSchedule(String scheduleid) {
		// TODO Auto-generated method stub
           flight.deleteFlightSchedule(scheduleid);
	}

	@Override
	public List<FlightSchedule> listFlightSchedule() {
		// TODO Auto-generated method stub
		return flight.listAll();
	}

	//@Override
/*	public void updateFlightSchedule(String scheduleid, String distance) {
		// TODO Auto-generated method stub

	}
*/
	@Override
	public FlightSchedule getFlightSchedule(String scheduleid) {
		return flight.getFlightScheduleByCode(scheduleid);
	}

}