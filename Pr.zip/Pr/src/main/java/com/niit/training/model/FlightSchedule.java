package com.niit.training.model;

//import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

//import org.springframework.format.annotation.DateTimeFormat;
@Entity
@Table(name="flight_schedule")
public class FlightSchedule {
	@Id
   private String scheduleid;
   private String source_airport;
   private String destination_airport;
   private String departure_time;
   private String arrival_time;
   private String duration;
   private String distance;
   private String date;
   private String flightCode;
   
   
   public FlightSchedule(){
	   
   }
 
public FlightSchedule(String scheduleid, String source_airport, String destination_airport, String departure_time,
		String arrival_time, String duration, String distance,String date,String flightCode) {
	super();
	this.scheduleid = scheduleid;
	this.source_airport = source_airport;
	this.destination_airport = destination_airport;
	this.departure_time = departure_time;
	this.arrival_time = arrival_time;
	this.duration = duration;
	this.distance = distance;
	this.date=date;
	this.flightCode=flightCode;
	
}
public String getFlightCode() {
	return flightCode;
}

public void setFlightCode(String flightCode) {
	this.flightCode = flightCode;
}

public String getScheduleid() {
	return scheduleid;
}
public void setScheduleid(String scheduleid) {
	this.scheduleid = scheduleid;
}
public String getDate() {
	return date;
}

public void setDate(String date) {
	this.date = date;
}

public String getSource_airport() {
	return source_airport;
}
public void setSource_airport(String source_airport) {
	this.source_airport = source_airport;
}
public String getDestination_airport() {
	return destination_airport;
}
public void setDestination_airport(String destination_airport) {
	this.destination_airport = destination_airport;
}
public String getDeparture_time() {
	return departure_time;
}
public void setDeparture_time(String departure_time) {
	this.departure_time = departure_time;
}
public String getArrival_time() {
	return arrival_time;
}
public void setArrival_time(String arrival_time) {
	this.arrival_time = arrival_time;
}
public String getDuration() {
	return duration;
}
public void setDuration(String duration) {
	this.duration = duration;
}
public String getDistance() {
	return distance;
}
public void setDistance(String distance) {
	this.distance = distance;
}




   
  
}
