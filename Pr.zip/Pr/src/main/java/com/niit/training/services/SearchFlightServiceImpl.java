package com.niit.training.services;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niit.training.dao.SearchFlightDao;
import com.niit.training.model.Flight;

@Service
@Transactional
public class SearchFlightServiceImpl implements SearchFlightService {

	List<Flight> flights = new ArrayList<Flight>();
	@Autowired
	SearchFlightDao searchDao;
	@Override
	public List<Flight> selectAllFlights(String sourceAirport, String destinationAirport, String date, int seats) {
		// TODO Auto-generated method stub
		flights = searchDao.selectAllFlights(sourceAirport, destinationAirport, date, seats);
		return flights;
	}

	@Override
	public int getAvailableSeats(String flightCode, int seats) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void updateSeats(String flightCode, int newSeats) {
		// TODO Auto-generated method stub

	}

}