package com.niit.training.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.training.services.AdminLoginService;

@Controller
public class AdminLoginController {

	@Autowired
	AdminLoginService service;
	
	@RequestMapping(value = "/adminlogin" , method = RequestMethod.GET)
	public ModelAndView adminLogin(@RequestParam String username, @RequestParam String password)
	{
		if(service.login(username, password))
		{
			ModelAndView view = new ModelAndView("Adminpanel");
			view.addObject("welcomeMsg","Welcome "+username);
			
			return view;
		}
		else
		{
			ModelAndView view = new ModelAndView("adminlogin");
			view.addObject("errorMsg","Incorrect username or password");
			return view;
		}
	}
}
