package com.niit.training.services;

public interface AdminLoginService {

	public boolean login(final String username,final String password);
	//spublic boolean validateAdmin(final String name, final String password);
}
