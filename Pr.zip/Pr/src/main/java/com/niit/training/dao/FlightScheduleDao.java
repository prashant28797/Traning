package com.niit.training.dao;

import java.util.List;

import com.niit.training.model.FlightSchedule;

public interface FlightScheduleDao {
	void add(FlightSchedule schedule);
	void deleteFlightSchedule(String scheduleid);
	List<FlightSchedule> listAll();
	//void update(FlightSchedule schedule);
	FlightSchedule getFlightScheduleByCode(String scheduleid);
}
