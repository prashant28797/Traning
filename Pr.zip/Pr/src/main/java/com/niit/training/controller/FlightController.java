package com.niit.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.niit.training.services.FlightService;
import com.niit.training.model.Flight;

@Controller
@SessionAttributes()
public class FlightController {
	@Autowired

	FlightService fservice;
/*	@RequestMapping(value = "/welcome", method = RequestMethod.GET)
	public String sayHello() {
		return "welcome";
	} */

	@RequestMapping(value = "/addFlight", method = RequestMethod.GET)
	public String say() {
		return "addflight";
	} 
	
	@RequestMapping(value = "/addFlight", method = RequestMethod.POST)
	public ModelAndView addFlight(String flightcode,String airlineCode,int seats) {
		if(fservice.getFlight( flightcode)!=null) {
			String msgValue = "Flight "+flightcode+" already present.";
			return new ModelAndView("addflight", "errorMessage", msgValue);
		}
		else {
			fservice.addFlight(flightcode,airlineCode,seats);
			String msgValue = "Flight with "+flightcode+" added.";
			return new ModelAndView("addflight", "message", msgValue);
		}
	}
	
	@RequestMapping(value = "/viewFlight", method = RequestMethod.GET)
	public ModelAndView listFlights() {
		List<Flight> flights = fservice.listAllFlight();
		System.out.println(flights);
		return new ModelAndView("viewflight","flights",flights);
	}
	
	@RequestMapping(value = "/deleteFlight", method = RequestMethod.GET)
	public ModelAndView deleteFlight(@RequestParam String flightCode) {
		fservice.deleteFlight(flightCode);
		ModelAndView view = new ModelAndView("viewflight");
		view.addObject("flights",fservice.listAllFlight());
		view.addObject("message","Flight updated successfully");
		return view;
	}
	}