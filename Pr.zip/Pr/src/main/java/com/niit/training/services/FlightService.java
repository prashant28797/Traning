package com.niit.training.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.niit.training.model.Flight;
@Service
public interface FlightService {
	
	void addFlight(String flightCode,String airlineCode, int seats);
	void deleteFlight(String flightCode);
	List<Flight> listAllFlight();
	//void updateFlight(String flightCode, String flightName,int seats);
	Flight getFlight(String flightCode);

}
