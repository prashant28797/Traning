package com.niit.training.model;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="flight")
public class Flight implements Serializable  {
	

	@Id
    private String flightCode;
	private String airlineCode;
	private int seats;
	public Flight() {
		// TODO Auto-generated constructor stub
	}


	public Flight(String flightCode, String airlineCode,int seats) {
		// TODO Auto-generated constructor stub
		this.flightCode = flightCode;
		this.airlineCode = airlineCode;
		this.seats = seats;
	}
	
	
	

	public String getFlightCode() {
		return flightCode;
	}


	public void setFlightCode(String flightCode) {
		this.flightCode = flightCode;
	}



	public String getairlineCode() {
		return airlineCode;
	}


	public void setairlineCode(String airlineCode) {
		this.airlineCode = airlineCode;
	}


	public int getSeats() {
		return seats;
	}


	public void setSeats(int seats) {
		this.seats = seats;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Flight other = (Flight) obj;
		if (airlineCode == null) {
			if (other.airlineCode != null)
				return false;
		} else if (!airlineCode.equals(other.airlineCode))
			return false;
		if (flightCode == null) {
			if (other.flightCode != null)
				return false;
		} else if (!flightCode.equals(other.flightCode))
			return false;
		
		if (seats != other.seats)
			return false;
		return true;
	}

	
}
