package com.niit.training.model;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="flight")
public class Flight implements Serializable  {
	

	@Id
	@Column(name = "flightcode")
    private String flightCode;
	
	@Column(name = "flightname", nullable = false)
	private String flightName;
	
	@Column(name = "airlinename", nullable = false)
	private String airlineName;
	
	@Column(name = "seats", nullable = false)
	private int seats;
	public Flight() {
		// TODO Auto-generated constructor stub
	}


	public Flight(String flightCode, String flightName, String airlineName,int seats) {
		// TODO Auto-generated constructor stub
		this.flightCode = flightCode;
		this.flightName = flightName;
		this.airlineName = airlineName;
		this.seats = seats;
	}
	
	
	

	public String getFlightCode() {
		return flightCode;
	}


	public void setFlightCode(String flightCode) {
		this.flightCode = flightCode;
	}


	public String getFlightName() {
		return flightName;
	}


	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}


	public String getAirlineName() {
		return airlineName;
	}


	public void setAirlineName(String airlineName) {
		this.airlineName = airlineName;
	}


	public int getSeats() {
		return seats;
	}


	public void setSeats(int seats) {
		this.seats = seats;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((airlineName == null) ? 0 : airlineName.hashCode());
		result = prime * result + ((flightCode == null) ? 0 : flightCode.hashCode());
		result = prime * result + ((flightName == null) ? 0 : flightName.hashCode());
		result = prime * result + seats;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Flight other = (Flight) obj;
		if (airlineName == null) {
			if (other.airlineName != null)
				return false;
		} else if (!airlineName.equals(other.airlineName))
			return false;
		if (flightCode == null) {
			if (other.flightCode != null)
				return false;
		} else if (!flightCode.equals(other.flightCode))
			return false;
		if (flightName == null) {
			if (other.flightName != null)
				return false;
		} else if (!flightName.equals(other.flightName))
			return false;
		if (seats != other.seats)
			return false;
		return true;
	}


	@Override
	public String toString() {
		return "Flight [flightCode=" + flightCode + ", flightName=" + flightName + ", airlineName=" + airlineName
				+ ", seats=" + seats + "]";
	}
	
}
