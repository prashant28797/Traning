package com.niit.training.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.niit.training.services.FlightScheduleService;

@Controller
@SessionAttributes()
public class FlightScheduleController {
	
	@Autowired
	FlightScheduleService fservice;
	
	@RequestMapping(value = "/addSchedule", method = RequestMethod.GET)
	public String sayHello() {
		return "FlightSchedule";
	}
	
	@RequestMapping(value = "/addSchedule", method = RequestMethod.POST)
	public ModelAndView adtSchedule(@RequestParam String scheduleid, @RequestParam String source_airport,
			@RequestParam String destination_airport,
			@RequestParam String departure_time,	@RequestParam String arrival_time,
				@RequestParam String duration,
			@RequestParam String distance,@RequestParam String date,@RequestParam String flightcode){
		
		if(fservice.getFlightSchedule(scheduleid) != null){
			String msgValue = "Flight "+scheduleid+" already present.";
			return new ModelAndView("FlightScedule", "errorMessage", msgValue);
	}
	else {
			fservice.addFlightSchedule(scheduleid,source_airport,destination_airport,departure_time,arrival_time,duration,distance,date,flightcode);
			String msgValue = "FLight with "+scheduleid+" added.";
			return new ModelAndView("FlightSchedule", "welcomeMessage", msgValue);
		}
	}
	
	@RequestMapping(value = "/listSchedule", method = RequestMethod.GET)
	public ModelAndView listSchedule() {
		
		return new ModelAndView("ScheduleList","list",fservice.listFlightSchedule());
	}
	
	@RequestMapping(value = "/deleteSchedule", method = RequestMethod.GET)
	public ModelAndView deleteUser(@RequestParam String scheduleid) {
		fservice.deleteFlightSchedule(scheduleid);
		
		ModelAndView view = new ModelAndView("ScheduleList");
		view.addObject("list",fservice.listFlightSchedule());
		view.addObject("message","User updated successfully");
		return view;
	}

}