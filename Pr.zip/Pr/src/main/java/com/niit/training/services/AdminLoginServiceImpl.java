package com.niit.training.services;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niit.training.dao.AdminLoginDao;

@Service
@Transactional
public class AdminLoginServiceImpl implements AdminLoginService {

	@Autowired
	AdminLoginDao adminDao ;
	@Override
	public boolean login(String username, String password) {
		// TODO Auto-generated method stub
		boolean exists = adminDao.login(username, password);
		return exists;

	}

	

}
