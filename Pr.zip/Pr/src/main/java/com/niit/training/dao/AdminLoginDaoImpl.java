package com.niit.training.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class AdminLoginDaoImpl implements AdminLoginDao {


	@Autowired
	SessionFactory sessionFactory;
	
	@Override
	public boolean  login(String username, String password) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		boolean userFound = false;
		
		String SQL_Query = "from Admin as a where a.username = ? and a.password = ?";
		Query query = session.createQuery(SQL_Query);
		query.setParameter(0, username);
		query.setParameter(1, password);
		List list = query.list();
		
		if(list!=null && list.size()>0)
		{
			userFound = true;
			return userFound;
		}
		return userFound;
	}

	
}
