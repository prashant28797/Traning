package com.niit.training.dao;

public interface AdminLoginDao {

	public boolean login(final String username, final String password);
	
}
