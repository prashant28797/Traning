package com.niit.training.dao;

import com.niit.training.model.User;

public interface UserDao {

	void adduser(User user);
	public boolean login(final String email_id, final String password);
	public User getUsername(final String email_id);

}