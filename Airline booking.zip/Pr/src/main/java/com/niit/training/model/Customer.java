package com.niit.training.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="customers")
public class Customer{
	@Id
	@Column(name="email")
	private String email;
	
	@Column(name="bookingid")
	private String bookingid;
	@Column(name="name")
	private String name;
	@Column(name="mobileno")
	private int mobileno;
	
	public Customer(String name, int mobileno, String email) {
		// TODO Auto-generated constructor stub
		this.name=name;
		this.mobileno=mobileno;
		
	}
	public String getBookingid() {
		return bookingid;
	}
	public void setBookingid(String bookingid) {
		this.bookingid = bookingid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMobileno() {
		return mobileno;
	}
	public void setMobileno(int mobileno) {
		this.mobileno = mobileno;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "Customer [bookingid=" + bookingid + ", name=" + name + ", mobileno=" + mobileno + ", email=" + email
				+ "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bookingid == null) ? 0 : bookingid.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + mobileno;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (bookingid == null) {
			if (other.bookingid != null)
				return false;
		} else if (!bookingid.equals(other.bookingid))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (mobileno != other.mobileno)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
	
	
}