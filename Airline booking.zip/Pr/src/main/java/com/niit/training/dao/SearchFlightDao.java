package com.niit.training.dao;

import java.util.List;

import com.niit.training.model.SearchFlight;

public interface SearchFlightDao {

	public List<SearchFlight> selectAllFlights(final String sourceAirport, final String destinationAirport, final String date);
	//public int getAvailableSeats(final String flightCode, int seats);
	//public void updateSeats(final String flightCode, final int newSeats);
}