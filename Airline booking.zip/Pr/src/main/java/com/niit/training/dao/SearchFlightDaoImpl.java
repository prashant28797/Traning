package com.niit.training.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.training.model.SearchFlight;

@Repository
public class SearchFlightDaoImpl implements SearchFlightDao {

	@Autowired
	SessionFactory sessionFactory;
	
	@Override
	public List<SearchFlight> selectAllFlights(String sourceAirport, String destinationAirport, String date) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();		
		//List<Flight> flights = session.createQuery("from Flight").list(); 
		/*String sql = "SELECT ar.code, ar.name, fs.distance, fl.flightCode, fs.Departure_time, fs.arrival_time, fl.seats, fs.source_airport,fs.destination_airport  FROM FlightSchedule fs, 	Flight fl , Airline ar Where fl.scheduleid = fs.Scheduleid AND fs.source_airport=? AND fs.destination_airport=? AND ar.Airlinecode=fl.airlinecode";
		Query query= session.createQuery(sql);*/
		
		String str="select fs.flightCode,fs.seats, sh.departure_time,sh.arrival_time,  as.airlineCode, as.cost from FlightSchedule sh, Flight fs, Airlines as where "
				   +"sh.source_airport = '"+sourceAirport
				   +"'and "+"sh.destination_airport='"+destinationAirport
				   +"'and "+"sh.date='"+date
				   +"' and sh.flightCode = fs.flightCode "
				   + "and fs.airlineCode = as.airlineCode";
		//System.out.println(query);
		System.out.println(str);
		Query query= session.createQuery(str);
		/*query.setParameter(0, sourceAirport);
		query.setParameter(1, destinationAirport);*/
		List<SearchFlight> flights = query.list();
		
		
		//System.out.println(flights);
 		return flights;
	}

/*	@Override
	public int getAvailableSeats(String flightCode, int seats) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void updateSeats(String flightCode, int newSeats) {
		// TODO Auto-generated method stub

	}*/

}
