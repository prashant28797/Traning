package com.niit.training.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.training.model.User;

@Repository
public class UserDaoImpl implements UserDao {
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void adduser(User user) {
		Session session = sessionFactory.getCurrentSession();
		session.save(user);
	}
	
	@Override
	public boolean login(String email_id, String password) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		boolean userFound = false;
		
		String SQL_Query = "from User as u where u.email_id = ? and u.password = ?";
		Query query = session.createQuery(SQL_Query);
		query.setParameter(0, email_id);
		query.setParameter(1, password);
		List list = query.list();
		if(list != null && list.size()>0)
		{
			userFound = true;
			return userFound;
		}
		return userFound;
	}
	@Override
	public User getUsername(String email_id) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		return (User) session.get(User.class, email_id);
		
	}
}

