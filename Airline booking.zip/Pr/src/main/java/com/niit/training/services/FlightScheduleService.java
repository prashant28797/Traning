package com.niit.training.services;

import java.util.List;

import com.niit.training.model.FlightSchedule;

public interface FlightScheduleService {
	
	void addFlightSchedule( String scheduleid, String source_airport, 
			 String destination_airport,
		 String departure_time,	 String arrival_time,
			 String duration,
			 String distance,String date,String flightCode);
	void deleteFlightSchedule(String scheduleid);
	List<FlightSchedule> listFlightSchedule();
	//void updateFlightSchedule(String flightcode, String distance);
	FlightSchedule getFlightSchedule(String scheduleid);

}

