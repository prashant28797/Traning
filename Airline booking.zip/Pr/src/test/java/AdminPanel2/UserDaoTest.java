package AdminPanel2;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.Before;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.jdbc.Sql;

public class UserDaoTest {
	
	@InjectMocks
	UserDaoImpl dao;
	
	@Mock
	private SessionFactory sessionFactory;
	@Mock
	Session session;
	
	Query value;
	
	@Sql
	
	@Before
	public void initial()
	
	{
		MockAnnotaions.initMocks(this);
		Mockito.when(session.createQuery(Mockito.anyString())).thenReturn
	}

}
