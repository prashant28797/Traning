package AdminPanel2;

import javax.inject.Inject;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.niit.training.dao.AdminLoginDao;
import com.niit.training.dao.UserDao;
import com.niit.training.model.Admin;
import com.niit.training.model.User;
import com.niit.training.services.AdminLoginService;
import com.niit.training.services.AdminLoginServiceImpl;

public class LoginServiceImplTest {

	@InjectMocks
	  AdminLoginServiceImpl impl;
		
		@Mock
		AdminLoginDao userDao;
	  
	  @Before
	  public void initialMethod()
	  {
		// impl=new LoginServiceImpl();
		  MockitoAnnotations.initMocks(this);
		  Admin user=new Admin("Amit","Password");
		  Mockito.when(userDao.get(Mockito.anyString())).thenReturn(user);
	  }
	  
	  @Test	
	  public void validateUserTest()
	  {
		 //.validateUserTest()
		  {
			 // assertTrue(impl.validateUser("Amit","Password"));
			//  assertNotNull(impl.findUser("Amit"));
			//(impl.listUsers().size()>0);
		  }
	  }
}
