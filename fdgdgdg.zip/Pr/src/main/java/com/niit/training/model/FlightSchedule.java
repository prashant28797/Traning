package com.niit.training.model;

//import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

//import org.springframework.format.annotation.DateTimeFormat;
@Entity
@Table(name="flight_schedule")
public class FlightSchedule {
	@Id
   private String scheduleid;
   private String source_airport;
   private String destination_airport;
   private String departure_time;
   private String arrival_time;
   private String duration;
   private String distance;
   private String date;
   
   
   public FlightSchedule(){
	   
   }
 
public FlightSchedule(String scheduleid, String source_airport, String destination_airport, String departure_time,
		String arrival_time, String duration, String distance) {
	super();
	this.scheduleid = scheduleid;
	this.source_airport = source_airport;
	this.destination_airport = destination_airport;
	this.departure_time = departure_time;
	this.arrival_time = arrival_time;
	this.duration = duration;
	this.distance = distance;
	
}
public String getScheduleid() {
	return scheduleid;
}
public void setScheduleid(String scheduleid) {
	this.scheduleid = scheduleid;
}
public String getDate() {
	return date;
}

public void setDate(String date) {
	this.date = date;
}

public String getSource_airport() {
	return source_airport;
}
public void setSource_airport(String source_airport) {
	this.source_airport = source_airport;
}
public String getDestination_airport() {
	return destination_airport;
}
public void setDestination_airport(String destination_airport) {
	this.destination_airport = destination_airport;
}
public String getDeparture_time() {
	return departure_time;
}
public void setDeparture_time(String departure_time) {
	this.departure_time = departure_time;
}
public String getArrival_time() {
	return arrival_time;
}
public void setArrival_time(String arrival_time) {
	this.arrival_time = arrival_time;
}
public String getDuration() {
	return duration;
}
public void setDuration(String duration) {
	this.duration = duration;
}
public String getDistance() {
	return distance;
}
public void setDistance(String distance) {
	this.distance = distance;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((arrival_time == null) ? 0 : arrival_time.hashCode());
	result = prime * result + ((date == null) ? 0 : date.hashCode());
	result = prime * result + ((departure_time == null) ? 0 : departure_time.hashCode());
	result = prime * result + ((destination_airport == null) ? 0 : destination_airport.hashCode());
	result = prime * result + ((distance == null) ? 0 : distance.hashCode());
	result = prime * result + ((duration == null) ? 0 : duration.hashCode());
	result = prime * result + ((scheduleid == null) ? 0 : scheduleid.hashCode());
	result = prime * result + ((source_airport == null) ? 0 : source_airport.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	FlightSchedule other = (FlightSchedule) obj;
	if (arrival_time == null) {
		if (other.arrival_time != null)
			return false;
	} else if (!arrival_time.equals(other.arrival_time))
		return false;
	if (date == null) {
		if (other.date != null)
			return false;
	} else if (!date.equals(other.date))
		return false;
	if (departure_time == null) {
		if (other.departure_time != null)
			return false;
	} else if (!departure_time.equals(other.departure_time))
		return false;
	if (destination_airport == null) {
		if (other.destination_airport != null)
			return false;
	} else if (!destination_airport.equals(other.destination_airport))
		return false;
	if (distance == null) {
		if (other.distance != null)
			return false;
	} else if (!distance.equals(other.distance))
		return false;
	if (duration == null) {
		if (other.duration != null)
			return false;
	} else if (!duration.equals(other.duration))
		return false;
	if (scheduleid == null) {
		if (other.scheduleid != null)
			return false;
	} else if (!scheduleid.equals(other.scheduleid))
		return false;
	if (source_airport == null) {
		if (other.source_airport != null)
			return false;
	} else if (!source_airport.equals(other.source_airport))
		return false;
	return true;
}
@Override
public String toString() {
	return "FlightSchedule [scheduleid=" + scheduleid + ", source_airport=" + source_airport + ", destination_airport="
			+ destination_airport + ", departure_time=" + departure_time + ", arrival_time=" + arrival_time
			+ ", duration=" + duration + ", distance=" + distance + ", date=" + date + "]";
}


   
  
}
