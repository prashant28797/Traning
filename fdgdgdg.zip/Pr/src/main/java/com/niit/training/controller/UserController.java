package com.niit.training.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.training.services.UserService;
import com.niit.training.model.User;

@Controller
public class UserController {

	@Autowired
	UserService service;
	
	@RequestMapping(value = "/addUser", method = RequestMethod.GET)
	public String customer()
	{
		return "user";
	}
	
	
	@RequestMapping(value = "/addUser" , method = RequestMethod.POST)
	public ModelAndView addUser(@RequestParam String firstName,
			@RequestParam String middleName
			, @RequestParam String lastName, @RequestParam String email_id
			,@RequestParam long contact
			,@RequestParam String password, @RequestParam String confirmPassword)
	{
		/*if(service.findUser(email_id))
		{
			String msgValue = "User with"+ firstName +"already exists";
			return new ModelAndView("user","message",msgValue);
		}
		else
		{*/
			//if(password.equals(confirmPassword)){
			service.addUser(email_id, password, firstName, middleName, lastName, contact);
			String msgValue = "Thank you"+ firstName+ "for registering";
			return new ModelAndView("user","message",msgValue);
		/*	}
			else
			{
				String msgValue = "Password Mismatch";
				return new ModelAndView("user","message",msgValue);
			}
		}*/
		
	}
}
