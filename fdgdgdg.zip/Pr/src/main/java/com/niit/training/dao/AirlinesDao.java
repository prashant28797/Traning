package com.niit.training.dao;

import java.util.List;
import com.niit.training.model.Airlines;

public interface AirlinesDao {

	void add(Airlines airline);
	void delete(String airlineCode);
	List<Airlines> listAll();
	void update(Airlines airline);
	Airlines getAirlineByCode(String airlineCode);
}
