package com.niit.training.dao;

import java.util.List;

import com.niit.training.model.Flight;

public interface FlightDao {
	void addflight(Flight flight);
	void delete(String flightCode);
	List<Flight> listAll();
	void update(Flight flight);
	Flight getFlightByCode(String flightCode);
	
}
