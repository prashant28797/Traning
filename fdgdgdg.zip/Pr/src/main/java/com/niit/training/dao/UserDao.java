package com.niit.training.dao;

import com.niit.training.model.User;

public interface UserDao {

	void adduser(User user);

}