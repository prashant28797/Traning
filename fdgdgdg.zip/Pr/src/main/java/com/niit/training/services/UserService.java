package com.niit.training.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.niit.training.model.User;

@Service
public interface UserService {

	//List<User> user = new ArrayList<User>();
	
	

	void addUser(String email_id, String password, String firstName, String middleName, String lastName,
			long contact);



	//boolean findUser(String email_id);



	//User findUserObj(String email_id);
	}
