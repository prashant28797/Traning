package com.niit.training.services;

import java.awt.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niit.training.model.Flight;
import com.niit.training.model.User;
import com.niit.training.dao.FlightDao;
import com.niit.training.dao.UserDao;


@Service
@Transactional
public class UserServiceImpl implements UserService {
	
	

	@Autowired
	UserDao userDao;
	
	public UserServiceImpl()
	{
		
	}
	
	@Override
	public void addUser(String email_id, String password, String firstName, String middleName, String lastName,
			long contact) {
		// TODO Auto-generated method stub
		User user = new User(email_id, password, firstName, middleName, lastName, contact);
		userDao.adduser(user);
	}

		

}
