package com.niit.training.services;


import java.util.List;

import javax.ejb.TransactionAttribute;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.niit.training.dao.FlightDao;
import com.niit.training.model.Flight;

@Service
@Transactional
class FlightServiceImp implements FlightService {

	@Autowired
	FlightDao flightDao;
	
	@Override
	public void addFlight(String flightName, String flightCode, String airlineName, int seats) {
		// TODO Auto-generated method stub
		Flight flight = new Flight(flightName,flightCode, airlineName,seats);
		flightDao.addflight(flight);
	}

	@Override
	public void deleteFlight(String flightCode) {
		// TODO Auto-generated method stub
		flightDao.delete(flightCode);
	}

	@Override
	public List<Flight> listAllFlight() {
		// TODO Auto-generated method stub
		return flightDao.listAll();
	}

	@Override
	public void updateFlight(String flightCode, String flightName, int seats) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Flight getFlight(String flightcode) {
		// TODO Auto-generated method stub
		return flightDao.getFlightByCode(flightcode);
	}

	
}
